# Transcript: DEMO: a polled condition that never becomes true

| | |
|---|---|
| Test | `com.qaautomation.tests.demo.DeliberateFailureTest#conditionNeverMetFails` |
| Features | FEAT-DEMO-01 |
| Attempt | 1 |
| Status | retried |
| Calls | 7 |

Secrets (tokens, passwords, credential headers) are masked as `****`.

| # | Call | Status | ms | Correlation ID |
|---|---|---|---|---|
| 1 | `POST /v1/accounts` | 201 | 541 | `qa-6963cea8-c19f-4171-a2f2-9ddc08131def` |
| 2 | `POST /v1/auth/token` | 200 | 30 | `qa-d38db8e0-6abf-4ecf-acfb-5927b56c1669` |
| 3 | `GET /v1/credits/balance` | 200 | 25 | `qa-03b4f6b5-8833-439c-bff9-7cd598f1302f` |
| 4 | `GET /v1/credits/balance` | 200 | 12 | `qa-1daed422-6dd8-46a7-a348-5673a3d93fc3` |
| 5 | `GET /v1/credits/balance` | 200 | 4 | `qa-75019705-68c8-4a4b-ad01-d466e48e9d56` |
| 6 | `DELETE /v1/accounts/me` | 204 | 5 | `qa-ee6f641d-7b4e-4d51-bde5-9e0cdb38ccb6` |
| 7 | `POST /v1/auth/token` | 401 | 4 | `qa-19bcbd8e-14ba-4239-966f-e806634d6f8f` |

## 1. POST /v1/accounts

```text
#1 POST http://localhost:7070/v1/accounts
correlation: qa-6963cea8-c19f-4171-a2f2-9ddc08131def

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-6963cea8-c19f-4171-a2f2-9ddc08131def
Content-Type: application/json

--- request body ---
{"handle":"qa-d2419c52f21c","displayName":"QA d2419c52f21c","password":"****","region":"eu"}

--- response: 201 in 541 ms ---
Date: Thu, 22 Oct 2026 04:40:52 GMT
Content-Type: application/json
X-Correlation-Id: qa-6963cea8-c19f-4171-a2f2-9ddc08131def
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 599
RateLimit-Reset: 10
Location: /v1/accounts/qa-d2419c52f21c
X-Served-Region: eu
Content-Length: 181

{"id":"acc_5d8ebdb4-5eb2-403b-a2ad-65ff7ae078e9","handle":"qa-d2419c52f21c","displayName":"QA d2419c52f21c","region":"eu","role":"user","createdAt":"2026-10-22T04:40:52.094676800Z"}
```

## 2. POST /v1/auth/token

```text
#2 POST http://localhost:7070/v1/auth/token
correlation: qa-d38db8e0-6abf-4ecf-acfb-5927b56c1669

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-d38db8e0-6abf-4ecf-acfb-5927b56c1669
Content-Type: application/json

--- request body ---
{"handle":"qa-d2419c52f21c","password":"****"}

--- response: 200 in 30 ms ---
Date: Thu, 22 Oct 2026 04:40:53 GMT
Content-Type: application/json
X-Correlation-Id: qa-d38db8e0-6abf-4ecf-acfb-5927b56c1669
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 585
RateLimit-Reset: 9
Content-Length: 153

{"accessToken":"****","tokenType":"Bearer","expiresIn":900,"accountId":"acc_5d8ebdb4-5eb2-403b-a2ad-65ff7ae078e9"}
```

## 3. GET /v1/credits/balance

```text
#3 GET http://localhost:7070/v1/credits/balance
correlation: qa-03b4f6b5-8833-439c-bff9-7cd598f1302f

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-03b4f6b5-8833-439c-bff9-7cd598f1302f
Content-Type: application/json

--- response: 200 in 25 ms ---
Date: Thu, 22 Oct 2026 04:40:53 GMT
Content-Type: application/json
X-Correlation-Id: qa-03b4f6b5-8833-439c-bff9-7cd598f1302f
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 60
RateLimit-Remaining: 59
RateLimit-Reset: 10
X-Served-Region: eu
Content-Length: 89

{"balance":5,"currency":"credits","accountId":"acc_5d8ebdb4-5eb2-403b-a2ad-65ff7ae078e9"}
```

## 4. GET /v1/credits/balance

```text
#4 GET http://localhost:7070/v1/credits/balance
correlation: qa-1daed422-6dd8-46a7-a348-5673a3d93fc3

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-1daed422-6dd8-46a7-a348-5673a3d93fc3
Content-Type: application/json

--- response: 200 in 12 ms ---
Date: Thu, 22 Oct 2026 04:40:53 GMT
Content-Type: application/json
X-Correlation-Id: qa-1daed422-6dd8-46a7-a348-5673a3d93fc3
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 60
RateLimit-Remaining: 58
RateLimit-Reset: 10
X-Served-Region: eu
Content-Length: 89

{"balance":5,"currency":"credits","accountId":"acc_5d8ebdb4-5eb2-403b-a2ad-65ff7ae078e9"}
```

## 5. GET /v1/credits/balance

```text
#5 GET http://localhost:7070/v1/credits/balance
correlation: qa-75019705-68c8-4a4b-ad01-d466e48e9d56

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-75019705-68c8-4a4b-ad01-d466e48e9d56
Content-Type: application/json

--- response: 200 in 4 ms ---
Date: Thu, 22 Oct 2026 04:40:54 GMT
Content-Type: application/json
X-Correlation-Id: qa-75019705-68c8-4a4b-ad01-d466e48e9d56
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 60
RateLimit-Remaining: 57
RateLimit-Reset: 9
X-Served-Region: eu
Content-Length: 89

{"balance":5,"currency":"credits","accountId":"acc_5d8ebdb4-5eb2-403b-a2ad-65ff7ae078e9"}
```

## 6. DELETE /v1/accounts/me

```text
#6 DELETE http://localhost:7070/v1/accounts/me
correlation: qa-ee6f641d-7b4e-4d51-bde5-9e0cdb38ccb6

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-ee6f641d-7b4e-4d51-bde5-9e0cdb38ccb6
Content-Type: application/json

--- response: 204 in 5 ms ---
Date: Thu, 22 Oct 2026 04:40:54 GMT
Content-Type: text/plain
X-Correlation-Id: qa-ee6f641d-7b4e-4d51-bde5-9e0cdb38ccb6
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 60
RateLimit-Remaining: 56
RateLimit-Reset: 9
X-Served-Region: eu
```

## 7. POST /v1/auth/token

```text
#7 POST http://localhost:7070/v1/auth/token
correlation: qa-19bcbd8e-14ba-4239-966f-e806634d6f8f

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-19bcbd8e-14ba-4239-966f-e806634d6f8f
Content-Type: application/json

--- request body ---
{"handle":"qa-d2419c52f21c","password":"****"}

--- response: 401 in 4 ms ---
Date: Thu, 22 Oct 2026 04:40:54 GMT
Content-Type: application/problem+json
X-Correlation-Id: qa-19bcbd8e-14ba-4239-966f-e806634d6f8f
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 579
RateLimit-Reset: 8
Content-Length: 242

{"type":"https://reference-service.example/problems/invalid-credentials","title":"Invalid credentials","status":401,"detail":"Handle or password is wrong.","instance":"/v1/auth/token","correlationId":"qa-19bcbd8e-14ba-4239-966f-e806634d6f8f"}
```
