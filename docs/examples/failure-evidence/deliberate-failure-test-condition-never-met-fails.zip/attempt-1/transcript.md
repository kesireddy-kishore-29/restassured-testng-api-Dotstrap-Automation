# Transcript: DEMO: a polled condition that never becomes true

| | |
|---|---|
| Test | `com.kishore.qa.tests.demo.DeliberateFailureTest#conditionNeverMetFails` |
| Features | FEAT-DEMO-01 |
| Attempt | 1 |
| Status | retried |
| Calls | 7 |

Secrets (tokens, passwords, credential headers) are masked as `****`.

| # | Call | Status | ms | Correlation ID |
|---|---|---|---|---|
| 1 | `POST /v1/accounts` | 201 | 832 | `qa-1cf5f2dd-06d3-4eb8-aa41-78e94ca9ce77` |
| 2 | `POST /v1/auth/token` | 200 | 30 | `qa-16bdf3f7-fd17-4ede-ab3e-2bc673012fc9` |
| 3 | `GET /v1/credits/balance` | 200 | 12 | `qa-af66362e-1948-47b5-8f4c-216e0a08e4fa` |
| 4 | `GET /v1/credits/balance` | 200 | 13 | `qa-47adcd5d-afa8-4d14-8328-e5ffa39cde8f` |
| 5 | `GET /v1/credits/balance` | 200 | 8 | `qa-305b0890-d397-403a-b231-a91e09d3301c` |
| 6 | `DELETE /v1/accounts/me` | 204 | 5 | `qa-cbff92b2-291b-4c9b-be83-a040e62e276d` |
| 7 | `POST /v1/auth/token` | 401 | 5 | `qa-ad7e08e4-c796-478c-b6e2-d79815777c30` |

## 1. POST /v1/accounts

```text
#1 POST http://localhost:7070/v1/accounts
correlation: qa-1cf5f2dd-06d3-4eb8-aa41-78e94ca9ce77

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-1cf5f2dd-06d3-4eb8-aa41-78e94ca9ce77
Content-Type: application/json

--- request body ---
{"handle":"qa-4a0956020a45","displayName":"QA 4a0956020a45","password":"****","region":"eu"}

--- response: 201 in 832 ms ---
Date: Wed, 21 Oct 2026 06:40:25 GMT
Content-Type: application/json
X-Correlation-Id: qa-1cf5f2dd-06d3-4eb8-aa41-78e94ca9ce77
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 598
RateLimit-Reset: 10
Location: /v1/accounts/qa-4a0956020a45
X-Served-Region: eu
Content-Length: 181

{"id":"acc_510bd802-b33e-472f-b6fc-77070cc4aa9a","handle":"qa-4a0956020a45","displayName":"QA 4a0956020a45","region":"eu","role":"user","createdAt":"2026-10-21T06:40:25.592956400Z"}
```

## 2. POST /v1/auth/token

```text
#2 POST http://localhost:7070/v1/auth/token
correlation: qa-16bdf3f7-fd17-4ede-ab3e-2bc673012fc9

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-16bdf3f7-fd17-4ede-ab3e-2bc673012fc9
Content-Type: application/json

--- request body ---
{"handle":"qa-4a0956020a45","password":"****"}

--- response: 200 in 30 ms ---
Date: Wed, 21 Oct 2026 06:40:26 GMT
Content-Type: application/json
X-Correlation-Id: qa-16bdf3f7-fd17-4ede-ab3e-2bc673012fc9
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 586
RateLimit-Reset: 9
Content-Length: 153

{"accessToken":"****","tokenType":"Bearer","expiresIn":900,"accountId":"acc_510bd802-b33e-472f-b6fc-77070cc4aa9a"}
```

## 3. GET /v1/credits/balance

```text
#3 GET http://localhost:7070/v1/credits/balance
correlation: qa-af66362e-1948-47b5-8f4c-216e0a08e4fa

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-af66362e-1948-47b5-8f4c-216e0a08e4fa
Content-Type: application/json

--- response: 200 in 12 ms ---
Date: Wed, 21 Oct 2026 06:40:26 GMT
Content-Type: application/json
X-Correlation-Id: qa-af66362e-1948-47b5-8f4c-216e0a08e4fa
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 60
RateLimit-Remaining: 59
RateLimit-Reset: 10
X-Served-Region: eu
Content-Length: 89

{"balance":5,"currency":"credits","accountId":"acc_510bd802-b33e-472f-b6fc-77070cc4aa9a"}
```

## 4. GET /v1/credits/balance

```text
#4 GET http://localhost:7070/v1/credits/balance
correlation: qa-47adcd5d-afa8-4d14-8328-e5ffa39cde8f

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-47adcd5d-afa8-4d14-8328-e5ffa39cde8f
Content-Type: application/json

--- response: 200 in 13 ms ---
Date: Wed, 21 Oct 2026 06:40:26 GMT
Content-Type: application/json
X-Correlation-Id: qa-47adcd5d-afa8-4d14-8328-e5ffa39cde8f
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 60
RateLimit-Remaining: 58
RateLimit-Reset: 10
X-Served-Region: eu
Content-Length: 89

{"balance":5,"currency":"credits","accountId":"acc_510bd802-b33e-472f-b6fc-77070cc4aa9a"}
```

## 5. GET /v1/credits/balance

```text
#5 GET http://localhost:7070/v1/credits/balance
correlation: qa-305b0890-d397-403a-b231-a91e09d3301c

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-305b0890-d397-403a-b231-a91e09d3301c
Content-Type: application/json

--- response: 200 in 8 ms ---
Date: Wed, 21 Oct 2026 06:40:27 GMT
Content-Type: application/json
X-Correlation-Id: qa-305b0890-d397-403a-b231-a91e09d3301c
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 60
RateLimit-Remaining: 57
RateLimit-Reset: 9
X-Served-Region: eu
Content-Length: 89

{"balance":5,"currency":"credits","accountId":"acc_510bd802-b33e-472f-b6fc-77070cc4aa9a"}
```

## 6. DELETE /v1/accounts/me

```text
#6 DELETE http://localhost:7070/v1/accounts/me
correlation: qa-cbff92b2-291b-4c9b-be83-a040e62e276d

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-cbff92b2-291b-4c9b-be83-a040e62e276d
Content-Type: application/json

--- response: 204 in 5 ms ---
Date: Wed, 21 Oct 2026 06:40:27 GMT
Content-Type: text/plain
X-Correlation-Id: qa-cbff92b2-291b-4c9b-be83-a040e62e276d
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 60
RateLimit-Remaining: 56
RateLimit-Reset: 9
X-Served-Region: eu
```

## 7. POST /v1/auth/token

```text
#7 POST http://localhost:7070/v1/auth/token
correlation: qa-ad7e08e4-c796-478c-b6e2-d79815777c30

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-ad7e08e4-c796-478c-b6e2-d79815777c30
Content-Type: application/json

--- request body ---
{"handle":"qa-4a0956020a45","password":"****"}

--- response: 401 in 5 ms ---
Date: Wed, 21 Oct 2026 06:40:28 GMT
Content-Type: application/problem+json
X-Correlation-Id: qa-ad7e08e4-c796-478c-b6e2-d79815777c30
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 579
RateLimit-Reset: 8
Content-Length: 242

{"type":"https://reference-service.example/problems/invalid-credentials","title":"Invalid credentials","status":401,"detail":"Handle or password is wrong.","instance":"/v1/auth/token","correlationId":"qa-ad7e08e4-c796-478c-b6e2-d79815777c30"}
```
