# Transcript: DEMO: a polled condition that never becomes true

| | |
|---|---|
| Test | `com.qaautomation.tests.demo.DeliberateFailureTest#conditionNeverMetFails` |
| Features | FEAT-DEMO-01 |
| Attempt | 1 |
| Status | retried |
| Calls | 7 |

Secrets (tokens, passwords, credential headers) are masked as `****`.

| # | Call | Status | ms | Correlation ID |
|---|---|---|---|---|
| 1 | `POST /v1/accounts` | 201 | 552 | `qa-1826df91-b7e4-45da-ab70-3393bcff2a18` |
| 2 | `POST /v1/auth/token` | 200 | 18 | `qa-1fcc775a-5ac7-428e-826d-aa1f546411ed` |
| 3 | `GET /v1/credits/balance` | 200 | 22 | `qa-b4843c6d-ecbb-4264-b84e-a50751bff302` |
| 4 | `GET /v1/credits/balance` | 200 | 9 | `qa-d67ab166-bc21-4128-9e63-18dd5a9a25a3` |
| 5 | `GET /v1/credits/balance` | 200 | 5 | `qa-790987e5-50c3-4a90-ac0c-9a4252596b62` |
| 6 | `DELETE /v1/accounts/me` | 204 | 7 | `qa-e7431e43-0477-429c-8ddc-37aa5fc746cf` |
| 7 | `POST /v1/auth/token` | 401 | 6 | `qa-2ca10d73-1473-4fea-b166-af743e147d5e` |

## 1. POST /v1/accounts

```text
#1 POST http://localhost:7070/v1/accounts
correlation: qa-1826df91-b7e4-45da-ab70-3393bcff2a18

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-1826df91-b7e4-45da-ab70-3393bcff2a18
Content-Type: application/json

--- request body ---
{"handle":"qa-59b5d187f135","displayName":"QA 59b5d187f135","password":"****","region":"eu"}

--- response: 201 in 552 ms ---
Date: Wed, 21 Oct 2026 16:02:52 GMT
Content-Type: application/json
X-Correlation-Id: qa-1826df91-b7e4-45da-ab70-3393bcff2a18
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 599
RateLimit-Reset: 10
Location: /v1/accounts/qa-59b5d187f135
X-Served-Region: eu
Content-Length: 181

{"id":"acc_82d57481-498c-4554-b016-27077c3c3f7d","handle":"qa-59b5d187f135","displayName":"QA 59b5d187f135","region":"eu","role":"user","createdAt":"2026-10-21T16:02:52.283657400Z"}
```

## 2. POST /v1/auth/token

```text
#2 POST http://localhost:7070/v1/auth/token
correlation: qa-1fcc775a-5ac7-428e-826d-aa1f546411ed

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-1fcc775a-5ac7-428e-826d-aa1f546411ed
Content-Type: application/json

--- request body ---
{"handle":"qa-59b5d187f135","password":"****"}

--- response: 200 in 18 ms ---
Date: Wed, 21 Oct 2026 16:02:53 GMT
Content-Type: application/json
X-Correlation-Id: qa-1fcc775a-5ac7-428e-826d-aa1f546411ed
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 584
RateLimit-Reset: 10
Content-Length: 153

{"accessToken":"****","tokenType":"Bearer","expiresIn":900,"accountId":"acc_82d57481-498c-4554-b016-27077c3c3f7d"}
```

## 3. GET /v1/credits/balance

```text
#3 GET http://localhost:7070/v1/credits/balance
correlation: qa-b4843c6d-ecbb-4264-b84e-a50751bff302

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-b4843c6d-ecbb-4264-b84e-a50751bff302
Content-Type: application/json

--- response: 200 in 22 ms ---
Date: Wed, 21 Oct 2026 16:02:53 GMT
Content-Type: application/json
X-Correlation-Id: qa-b4843c6d-ecbb-4264-b84e-a50751bff302
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 60
RateLimit-Remaining: 59
RateLimit-Reset: 10
X-Served-Region: eu
Content-Length: 89

{"balance":5,"currency":"credits","accountId":"acc_82d57481-498c-4554-b016-27077c3c3f7d"}
```

## 4. GET /v1/credits/balance

```text
#4 GET http://localhost:7070/v1/credits/balance
correlation: qa-d67ab166-bc21-4128-9e63-18dd5a9a25a3

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-d67ab166-bc21-4128-9e63-18dd5a9a25a3
Content-Type: application/json

--- response: 200 in 9 ms ---
Date: Wed, 21 Oct 2026 16:02:53 GMT
Content-Type: application/json
X-Correlation-Id: qa-d67ab166-bc21-4128-9e63-18dd5a9a25a3
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 60
RateLimit-Remaining: 58
RateLimit-Reset: 10
X-Served-Region: eu
Content-Length: 89

{"balance":5,"currency":"credits","accountId":"acc_82d57481-498c-4554-b016-27077c3c3f7d"}
```

## 5. GET /v1/credits/balance

```text
#5 GET http://localhost:7070/v1/credits/balance
correlation: qa-790987e5-50c3-4a90-ac0c-9a4252596b62

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-790987e5-50c3-4a90-ac0c-9a4252596b62
Content-Type: application/json

--- response: 200 in 5 ms ---
Date: Wed, 21 Oct 2026 16:02:54 GMT
Content-Type: application/json
X-Correlation-Id: qa-790987e5-50c3-4a90-ac0c-9a4252596b62
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 60
RateLimit-Remaining: 57
RateLimit-Reset: 9
X-Served-Region: eu
Content-Length: 89

{"balance":5,"currency":"credits","accountId":"acc_82d57481-498c-4554-b016-27077c3c3f7d"}
```

## 6. DELETE /v1/accounts/me

```text
#6 DELETE http://localhost:7070/v1/accounts/me
correlation: qa-e7431e43-0477-429c-8ddc-37aa5fc746cf

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-e7431e43-0477-429c-8ddc-37aa5fc746cf
Content-Type: application/json

--- response: 204 in 7 ms ---
Date: Wed, 21 Oct 2026 16:02:54 GMT
Content-Type: text/plain
X-Correlation-Id: qa-e7431e43-0477-429c-8ddc-37aa5fc746cf
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 60
RateLimit-Remaining: 56
RateLimit-Reset: 9
X-Served-Region: eu
```

## 7. POST /v1/auth/token

```text
#7 POST http://localhost:7070/v1/auth/token
correlation: qa-2ca10d73-1473-4fea-b166-af743e147d5e

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-2ca10d73-1473-4fea-b166-af743e147d5e
Content-Type: application/json

--- request body ---
{"handle":"qa-59b5d187f135","password":"****"}

--- response: 401 in 6 ms ---
Date: Wed, 21 Oct 2026 16:02:54 GMT
Content-Type: application/problem+json
X-Correlation-Id: qa-2ca10d73-1473-4fea-b166-af743e147d5e
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 579
RateLimit-Reset: 8
Content-Length: 242

{"type":"https://reference-service.example/problems/invalid-credentials","title":"Invalid credentials","status":401,"detail":"Handle or password is wrong.","instance":"/v1/auth/token","correlationId":"qa-2ca10d73-1473-4fea-b166-af743e147d5e"}
```
