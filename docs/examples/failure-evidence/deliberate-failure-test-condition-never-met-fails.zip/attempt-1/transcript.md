# Transcript: DEMO: a polled condition that never becomes true

| | |
|---|---|
| Test | `com.qaautomation.tests.demo.DeliberateFailureTest#conditionNeverMetFails` |
| Features | FEAT-DEMO-01 |
| Attempt | 1 |
| Status | retried |
| Calls | 7 |

Secrets (tokens, passwords, credential headers) are masked as `****`.

| # | Call | Status | ms | Correlation ID |
|---|---|---|---|---|
| 1 | `POST /v1/accounts` | 201 | 831 | `qa-07574061-e2fc-43cb-8daf-7f346a83e478` |
| 2 | `POST /v1/auth/token` | 200 | 17 | `qa-69fec79b-d0d0-4f8d-a2fb-b8ab6c2548b0` |
| 3 | `GET /v1/credits/balance` | 200 | 35 | `qa-6acc4c8b-57d3-4121-89de-e7f9188c113b` |
| 4 | `GET /v1/credits/balance` | 200 | 11 | `qa-a6ab5bed-885d-42a7-9b08-42e5a8e2f2f0` |
| 5 | `GET /v1/credits/balance` | 200 | 7 | `qa-add735a0-0a64-4412-a0b1-a14d49ece3e9` |
| 6 | `DELETE /v1/accounts/me` | 204 | 11 | `qa-66a8fd54-34a4-4d21-9e04-8329bfd34a76` |
| 7 | `POST /v1/auth/token` | 401 | 9 | `qa-eec949b6-1dfb-4208-bfa7-58d09f21a226` |

## 1. POST /v1/accounts

```text
#1 POST http://localhost:7070/v1/accounts
correlation: qa-07574061-e2fc-43cb-8daf-7f346a83e478

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-07574061-e2fc-43cb-8daf-7f346a83e478
Content-Type: application/json

--- request body ---
{"handle":"qa-3ea42016ef83","displayName":"QA 3ea42016ef83","password":"****","region":"eu"}

--- response: 201 in 831 ms ---
Date: Wed, 21 Oct 2026 14:49:48 GMT
Content-Type: application/json
X-Correlation-Id: qa-07574061-e2fc-43cb-8daf-7f346a83e478
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 596
RateLimit-Reset: 10
Location: /v1/accounts/qa-3ea42016ef83
X-Served-Region: eu
Content-Length: 181

{"id":"acc_69119286-a934-437c-9569-d0d2d6d575f9","handle":"qa-3ea42016ef83","displayName":"QA 3ea42016ef83","region":"eu","role":"user","createdAt":"2026-10-21T14:49:48.238575100Z"}
```

## 2. POST /v1/auth/token

```text
#2 POST http://localhost:7070/v1/auth/token
correlation: qa-69fec79b-d0d0-4f8d-a2fb-b8ab6c2548b0

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-69fec79b-d0d0-4f8d-a2fb-b8ab6c2548b0
Content-Type: application/json

--- request body ---
{"handle":"qa-3ea42016ef83","password":"****"}

--- response: 200 in 17 ms ---
Date: Wed, 21 Oct 2026 14:49:49 GMT
Content-Type: application/json
X-Correlation-Id: qa-69fec79b-d0d0-4f8d-a2fb-b8ab6c2548b0
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 589
RateLimit-Reset: 9
Content-Length: 153

{"accessToken":"****","tokenType":"Bearer","expiresIn":900,"accountId":"acc_69119286-a934-437c-9569-d0d2d6d575f9"}
```

## 3. GET /v1/credits/balance

```text
#3 GET http://localhost:7070/v1/credits/balance
correlation: qa-6acc4c8b-57d3-4121-89de-e7f9188c113b

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-6acc4c8b-57d3-4121-89de-e7f9188c113b
Content-Type: application/json

--- response: 200 in 35 ms ---
Date: Wed, 21 Oct 2026 14:49:49 GMT
Content-Type: application/json
X-Correlation-Id: qa-6acc4c8b-57d3-4121-89de-e7f9188c113b
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 60
RateLimit-Remaining: 59
RateLimit-Reset: 10
X-Served-Region: eu
Content-Length: 89

{"balance":5,"currency":"credits","accountId":"acc_69119286-a934-437c-9569-d0d2d6d575f9"}
```

## 4. GET /v1/credits/balance

```text
#4 GET http://localhost:7070/v1/credits/balance
correlation: qa-a6ab5bed-885d-42a7-9b08-42e5a8e2f2f0

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-a6ab5bed-885d-42a7-9b08-42e5a8e2f2f0
Content-Type: application/json

--- response: 200 in 11 ms ---
Date: Wed, 21 Oct 2026 14:49:49 GMT
Content-Type: application/json
X-Correlation-Id: qa-a6ab5bed-885d-42a7-9b08-42e5a8e2f2f0
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 60
RateLimit-Remaining: 58
RateLimit-Reset: 10
X-Served-Region: eu
Content-Length: 89

{"balance":5,"currency":"credits","accountId":"acc_69119286-a934-437c-9569-d0d2d6d575f9"}
```

## 5. GET /v1/credits/balance

```text
#5 GET http://localhost:7070/v1/credits/balance
correlation: qa-add735a0-0a64-4412-a0b1-a14d49ece3e9

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-add735a0-0a64-4412-a0b1-a14d49ece3e9
Content-Type: application/json

--- response: 200 in 7 ms ---
Date: Wed, 21 Oct 2026 14:49:50 GMT
Content-Type: application/json
X-Correlation-Id: qa-add735a0-0a64-4412-a0b1-a14d49ece3e9
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 60
RateLimit-Remaining: 57
RateLimit-Reset: 9
X-Served-Region: eu
Content-Length: 89

{"balance":5,"currency":"credits","accountId":"acc_69119286-a934-437c-9569-d0d2d6d575f9"}
```

## 6. DELETE /v1/accounts/me

```text
#6 DELETE http://localhost:7070/v1/accounts/me
correlation: qa-66a8fd54-34a4-4d21-9e04-8329bfd34a76

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-66a8fd54-34a4-4d21-9e04-8329bfd34a76
Content-Type: application/json

--- response: 204 in 11 ms ---
Date: Wed, 21 Oct 2026 14:49:50 GMT
Content-Type: text/plain
X-Correlation-Id: qa-66a8fd54-34a4-4d21-9e04-8329bfd34a76
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 60
RateLimit-Remaining: 56
RateLimit-Reset: 9
X-Served-Region: eu
```

## 7. POST /v1/auth/token

```text
#7 POST http://localhost:7070/v1/auth/token
correlation: qa-eec949b6-1dfb-4208-bfa7-58d09f21a226

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-eec949b6-1dfb-4208-bfa7-58d09f21a226
Content-Type: application/json

--- request body ---
{"handle":"qa-3ea42016ef83","password":"****"}

--- response: 401 in 9 ms ---
Date: Wed, 21 Oct 2026 14:49:50 GMT
Content-Type: application/problem+json
X-Correlation-Id: qa-eec949b6-1dfb-4208-bfa7-58d09f21a226
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 579
RateLimit-Reset: 8
Content-Length: 242

{"type":"https://reference-service.example/problems/invalid-credentials","title":"Invalid credentials","status":401,"detail":"Handle or password is wrong.","instance":"/v1/auth/token","correlationId":"qa-eec949b6-1dfb-4208-bfa7-58d09f21a226"}
```
