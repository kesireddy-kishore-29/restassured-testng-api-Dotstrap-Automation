# Transcript: Balance, ledger and purchase match their schemas

| | |
|---|---|
| Test | `com.qaautomation.tests.contract.ContractTest#creditResourcesMatchTheirContracts` |
| Features | FEAT-CONTRACT-01 |
| Attempt | 1 |
| Status | retried |
| Calls | 5 |

Secrets (tokens, passwords, credential headers) are masked as `****`.

| # | Call | Status | ms | Correlation ID |
|---|---|---|---|---|
| 1 | `POST /v1/accounts` | 201 | 703 | `qa-206123a6-a4b3-4480-a591-3baea925f76a` |
| 2 | `POST /v1/auth/token` | 200 | 67 | `qa-98e9c755-39f9-4c94-b199-3c41a61e6a04` |
| 3 | `GET /v1/credits/balance` | 200 | 54 | `qa-a1577154-13e2-401e-b91c-20b174f77a2b` |
| 4 | `DELETE /v1/accounts/me` | 204 | 18 | `qa-d74b31af-e41c-46cf-86c8-d3150b50ac78` |
| 5 | `POST /v1/auth/token` | 401 | 70 | `qa-d7f27b9c-13b0-44b4-b533-502281d240d3` |

## 1. POST /v1/accounts

```text
#1 POST http://localhost:7070/v1/accounts
correlation: qa-206123a6-a4b3-4480-a591-3baea925f76a

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-206123a6-a4b3-4480-a591-3baea925f76a
Content-Type: application/json

--- request body ---
{"handle":"qa-09d6f88de431","displayName":"QA 09d6f88de431","password":"****","region":"in"}

--- response: 201 in 703 ms ---
Date: Wed, 21 Oct 2026 14:51:08 GMT
Content-Type: application/json
X-Correlation-Id: qa-206123a6-a4b3-4480-a591-3baea925f76a
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 598
RateLimit-Reset: 10
Location: /v1/accounts/qa-09d6f88de431
X-Served-Region: in
Content-Length: 178

{"id":"acc_591ba0e5-9eed-44ae-8a79-03c7d3cb96b3","handle":"qa-09d6f88de431","displayName":"QA 09d6f88de431","region":"in","role":"user","createdAt":"2026-10-21T14:51:08.149330Z"}
```

## 2. POST /v1/auth/token

```text
#2 POST http://localhost:7070/v1/auth/token
correlation: qa-98e9c755-39f9-4c94-b199-3c41a61e6a04

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-98e9c755-39f9-4c94-b199-3c41a61e6a04
Content-Type: application/json

--- request body ---
{"handle":"qa-09d6f88de431","password":"****"}

--- response: 200 in 67 ms ---
Date: Wed, 21 Oct 2026 14:51:08 GMT
Content-Type: application/json
X-Correlation-Id: qa-98e9c755-39f9-4c94-b199-3c41a61e6a04
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 592
RateLimit-Reset: 10
Content-Length: 153

{"accessToken":"****","tokenType":"Bearer","expiresIn":900,"accountId":"acc_591ba0e5-9eed-44ae-8a79-03c7d3cb96b3"}
```

## 3. GET /v1/credits/balance

```text
#3 GET http://localhost:7070/v1/credits/balance
correlation: qa-a1577154-13e2-401e-b91c-20b174f77a2b

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-a1577154-13e2-401e-b91c-20b174f77a2b
Content-Type: application/json

--- response: 200 in 54 ms ---
Date: Wed, 21 Oct 2026 14:51:08 GMT
Content-Type: application/json
X-Correlation-Id: qa-a1577154-13e2-401e-b91c-20b174f77a2b
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 60
RateLimit-Remaining: 59
RateLimit-Reset: 10
X-Served-Region: in
Content-Length: 98

{"availableBalance":5,"currency":"credits","accountId":"acc_591ba0e5-9eed-44ae-8a79-03c7d3cb96b3"}
```

## 4. DELETE /v1/accounts/me

```text
#4 DELETE http://localhost:7070/v1/accounts/me
correlation: qa-d74b31af-e41c-46cf-86c8-d3150b50ac78

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-d74b31af-e41c-46cf-86c8-d3150b50ac78
Content-Type: application/json

--- response: 204 in 18 ms ---
Date: Wed, 21 Oct 2026 14:51:09 GMT
Content-Type: text/plain
X-Correlation-Id: qa-d74b31af-e41c-46cf-86c8-d3150b50ac78
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 60
RateLimit-Remaining: 58
RateLimit-Reset: 10
X-Served-Region: in
```

## 5. POST /v1/auth/token

```text
#5 POST http://localhost:7070/v1/auth/token
correlation: qa-d7f27b9c-13b0-44b4-b533-502281d240d3

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-d7f27b9c-13b0-44b4-b533-502281d240d3
Content-Type: application/json

--- request body ---
{"handle":"qa-09d6f88de431","password":"****"}

--- response: 401 in 70 ms ---
Date: Wed, 21 Oct 2026 14:51:09 GMT
Content-Type: application/problem+json
X-Correlation-Id: qa-d7f27b9c-13b0-44b4-b533-502281d240d3
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 587
RateLimit-Reset: 9
Content-Length: 242

{"type":"https://reference-service.example/problems/invalid-credentials","title":"Invalid credentials","status":401,"detail":"Handle or password is wrong.","instance":"/v1/auth/token","correlationId":"qa-d7f27b9c-13b0-44b4-b533-502281d240d3"}
```
