# Transcript: Balance, ledger and purchase match their schemas

| | |
|---|---|
| Test | `com.kishore.qa.tests.contract.ContractTest#creditResourcesMatchTheirContracts` |
| Features | FEAT-CONTRACT-01 |
| Attempt | 1 |
| Status | retried |
| Calls | 5 |

Secrets (tokens, passwords, credential headers) are masked as `****`.

| # | Call | Status | ms | Correlation ID |
|---|---|---|---|---|
| 1 | `POST /v1/accounts` | 201 | 477 | `qa-64800717-7fbf-4865-b59f-9ae14f7d9011` |
| 2 | `POST /v1/auth/token` | 200 | 23 | `qa-a6ab03e7-3a4a-488c-b004-db0f7276de15` |
| 3 | `GET /v1/credits/balance` | 200 | 16 | `qa-9cb22315-e5fa-4e18-8631-47ecbfe1c01c` |
| 4 | `DELETE /v1/accounts/me` | 204 | 16 | `qa-502ae18b-cc6f-453a-9802-bd3b536b539a` |
| 5 | `POST /v1/auth/token` | 401 | 17 | `qa-e75bb716-919f-410f-a150-0e0d7abb53ad` |

## 1. POST /v1/accounts

```text
#1 POST http://localhost:7070/v1/accounts
correlation: qa-64800717-7fbf-4865-b59f-9ae14f7d9011

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-64800717-7fbf-4865-b59f-9ae14f7d9011
Content-Type: application/json

--- request body ---
{"handle":"qa-27a76855c3ca","displayName":"QA 27a76855c3ca","password":"****","region":"in"}

--- response: 201 in 477 ms ---
Date: Wed, 21 Oct 2026 06:08:00 GMT
Content-Type: application/json
X-Correlation-Id: qa-64800717-7fbf-4865-b59f-9ae14f7d9011
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 596
RateLimit-Reset: 10
Location: /v1/accounts/qa-27a76855c3ca
X-Served-Region: in
Content-Length: 181

{"id":"acc_f88ba7a9-cfb3-4623-aa50-ea860287ab36","handle":"qa-27a76855c3ca","displayName":"QA 27a76855c3ca","region":"in","role":"user","createdAt":"2026-10-21T06:08:00.941383200Z"}
```

## 2. POST /v1/auth/token

```text
#2 POST http://localhost:7070/v1/auth/token
correlation: qa-a6ab03e7-3a4a-488c-b004-db0f7276de15

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-a6ab03e7-3a4a-488c-b004-db0f7276de15
Content-Type: application/json

--- request body ---
{"handle":"qa-27a76855c3ca","password":"****"}

--- response: 200 in 23 ms ---
Date: Wed, 21 Oct 2026 06:08:01 GMT
Content-Type: application/json
X-Correlation-Id: qa-a6ab03e7-3a4a-488c-b004-db0f7276de15
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 592
RateLimit-Reset: 10
Content-Length: 153

{"accessToken":"****","tokenType":"Bearer","expiresIn":900,"accountId":"acc_f88ba7a9-cfb3-4623-aa50-ea860287ab36"}
```

## 3. GET /v1/credits/balance

```text
#3 GET http://localhost:7070/v1/credits/balance
correlation: qa-9cb22315-e5fa-4e18-8631-47ecbfe1c01c

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-9cb22315-e5fa-4e18-8631-47ecbfe1c01c
Content-Type: application/json

--- response: 200 in 16 ms ---
Date: Wed, 21 Oct 2026 06:08:01 GMT
Content-Type: application/json
X-Correlation-Id: qa-9cb22315-e5fa-4e18-8631-47ecbfe1c01c
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 60
RateLimit-Remaining: 59
RateLimit-Reset: 10
X-Served-Region: in
Content-Length: 98

{"availableBalance":5,"currency":"credits","accountId":"acc_f88ba7a9-cfb3-4623-aa50-ea860287ab36"}
```

## 4. DELETE /v1/accounts/me

```text
#4 DELETE http://localhost:7070/v1/accounts/me
correlation: qa-502ae18b-cc6f-453a-9802-bd3b536b539a

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-502ae18b-cc6f-453a-9802-bd3b536b539a
Content-Type: application/json

--- response: 204 in 16 ms ---
Date: Wed, 21 Oct 2026 06:08:01 GMT
Content-Type: text/plain
X-Correlation-Id: qa-502ae18b-cc6f-453a-9802-bd3b536b539a
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 60
RateLimit-Remaining: 58
RateLimit-Reset: 10
X-Served-Region: in
```

## 5. POST /v1/auth/token

```text
#5 POST http://localhost:7070/v1/auth/token
correlation: qa-e75bb716-919f-410f-a150-0e0d7abb53ad

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-e75bb716-919f-410f-a150-0e0d7abb53ad
Content-Type: application/json

--- request body ---
{"handle":"qa-27a76855c3ca","password":"****"}

--- response: 401 in 17 ms ---
Date: Wed, 21 Oct 2026 06:08:01 GMT
Content-Type: application/problem+json
X-Correlation-Id: qa-e75bb716-919f-410f-a150-0e0d7abb53ad
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 587
RateLimit-Reset: 10
Content-Length: 242

{"type":"https://reference-service.example/problems/invalid-credentials","title":"Invalid credentials","status":401,"detail":"Handle or password is wrong.","instance":"/v1/auth/token","correlationId":"qa-e75bb716-919f-410f-a150-0e0d7abb53ad"}
```
