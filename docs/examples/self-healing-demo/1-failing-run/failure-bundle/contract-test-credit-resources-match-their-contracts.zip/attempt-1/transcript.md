# Transcript: Balance, ledger and purchase match their schemas

| | |
|---|---|
| Test | `com.qaautomation.tests.contract.ContractTest#creditResourcesMatchTheirContracts` |
| Features | FEAT-CONTRACT-01 |
| Attempt | 1 |
| Status | retried |
| Calls | 5 |

Secrets (tokens, passwords, credential headers) are masked as `****`.

| # | Call | Status | ms | Correlation ID |
|---|---|---|---|---|
| 1 | `POST /v1/accounts` | 201 | 570 | `qa-8609f9a5-8d41-4090-a726-7e69936ecd86` |
| 2 | `POST /v1/auth/token` | 200 | 53 | `qa-7fd536cf-70e2-4ed0-a3e1-11e440982eaa` |
| 3 | `GET /v1/credits/balance` | 200 | 56 | `qa-b6a39fe5-554b-4bfc-8aa4-5c1819007f84` |
| 4 | `DELETE /v1/accounts/me` | 204 | 49 | `qa-e79becf8-d2e5-4f0d-8d85-866070cce9e2` |
| 5 | `POST /v1/auth/token` | 401 | 45 | `qa-c37365f1-b9e3-4b34-8b0f-71d6343cb902` |

## 1. POST /v1/accounts

```text
#1 POST http://localhost:7070/v1/accounts
correlation: qa-8609f9a5-8d41-4090-a726-7e69936ecd86

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-8609f9a5-8d41-4090-a726-7e69936ecd86
Content-Type: application/json

--- request body ---
{"handle":"qa-f26ead7e8ef8","displayName":"QA f26ead7e8ef8","password":"****","region":"in"}

--- response: 201 in 570 ms ---
Date: Wed, 21 Oct 2026 16:07:29 GMT
Content-Type: application/json
X-Correlation-Id: qa-8609f9a5-8d41-4090-a726-7e69936ecd86
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 598
RateLimit-Reset: 10
Location: /v1/accounts/qa-f26ead7e8ef8
X-Served-Region: in
Content-Length: 181

{"id":"acc_a4ea9a9d-5087-4045-9226-e753804ad8a7","handle":"qa-f26ead7e8ef8","displayName":"QA f26ead7e8ef8","region":"in","role":"user","createdAt":"2026-10-21T16:07:29.677907400Z"}
```

## 2. POST /v1/auth/token

```text
#2 POST http://localhost:7070/v1/auth/token
correlation: qa-7fd536cf-70e2-4ed0-a3e1-11e440982eaa

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-7fd536cf-70e2-4ed0-a3e1-11e440982eaa
Content-Type: application/json

--- request body ---
{"handle":"qa-f26ead7e8ef8","password":"****"}

--- response: 200 in 53 ms ---
Date: Wed, 21 Oct 2026 16:07:30 GMT
Content-Type: application/json
X-Correlation-Id: qa-7fd536cf-70e2-4ed0-a3e1-11e440982eaa
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 592
RateLimit-Reset: 10
Content-Length: 153

{"accessToken":"****","tokenType":"Bearer","expiresIn":900,"accountId":"acc_a4ea9a9d-5087-4045-9226-e753804ad8a7"}
```

## 3. GET /v1/credits/balance

```text
#3 GET http://localhost:7070/v1/credits/balance
correlation: qa-b6a39fe5-554b-4bfc-8aa4-5c1819007f84

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-b6a39fe5-554b-4bfc-8aa4-5c1819007f84
Content-Type: application/json

--- response: 200 in 56 ms ---
Date: Wed, 21 Oct 2026 16:07:30 GMT
Content-Type: application/json
X-Correlation-Id: qa-b6a39fe5-554b-4bfc-8aa4-5c1819007f84
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 60
RateLimit-Remaining: 59
RateLimit-Reset: 10
X-Served-Region: in
Content-Length: 98

{"availableBalance":5,"currency":"credits","accountId":"acc_a4ea9a9d-5087-4045-9226-e753804ad8a7"}
```

## 4. DELETE /v1/accounts/me

```text
#4 DELETE http://localhost:7070/v1/accounts/me
correlation: qa-e79becf8-d2e5-4f0d-8d85-866070cce9e2

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-e79becf8-d2e5-4f0d-8d85-866070cce9e2
Content-Type: application/json

--- response: 204 in 49 ms ---
Date: Wed, 21 Oct 2026 16:07:30 GMT
Content-Type: text/plain
X-Correlation-Id: qa-e79becf8-d2e5-4f0d-8d85-866070cce9e2
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 60
RateLimit-Remaining: 58
RateLimit-Reset: 10
X-Served-Region: in
```

## 5. POST /v1/auth/token

```text
#5 POST http://localhost:7070/v1/auth/token
correlation: qa-c37365f1-b9e3-4b34-8b0f-71d6343cb902

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-c37365f1-b9e3-4b34-8b0f-71d6343cb902
Content-Type: application/json

--- request body ---
{"handle":"qa-f26ead7e8ef8","password":"****"}

--- response: 401 in 45 ms ---
Date: Wed, 21 Oct 2026 16:07:30 GMT
Content-Type: application/problem+json
X-Correlation-Id: qa-c37365f1-b9e3-4b34-8b0f-71d6343cb902
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 587
RateLimit-Reset: 10
Content-Length: 242

{"type":"https://reference-service.example/problems/invalid-credentials","title":"Invalid credentials","status":401,"detail":"Handle or password is wrong.","instance":"/v1/auth/token","correlationId":"qa-c37365f1-b9e3-4b34-8b0f-71d6343cb902"}
```
