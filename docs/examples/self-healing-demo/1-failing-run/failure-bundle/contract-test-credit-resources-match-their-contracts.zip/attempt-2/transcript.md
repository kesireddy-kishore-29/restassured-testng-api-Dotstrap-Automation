# Transcript: Balance, ledger and purchase match their schemas

| | |
|---|---|
| Test | `com.qaautomation.tests.contract.ContractTest#creditResourcesMatchTheirContracts` |
| Features | FEAT-CONTRACT-01 |
| Attempt | 2 |
| Status | retried |
| Calls | 5 |

Secrets (tokens, passwords, credential headers) are masked as `****`.

| # | Call | Status | ms | Correlation ID |
|---|---|---|---|---|
| 1 | `POST /v1/accounts` | 201 | 33 | `qa-4b481a46-42c0-4955-ac08-5d96630ae470` |
| 2 | `POST /v1/auth/token` | 200 | 242 | `qa-54151571-7590-4b87-9336-709bb30b1ddc` |
| 3 | `GET /v1/credits/balance` | 200 | 63 | `qa-831fd29f-2fbc-4bff-ad38-5b0c2854de35` |
| 4 | `DELETE /v1/accounts/me` | 204 | 86 | `qa-6ebeef94-0652-4a28-b6ae-befc48d310d3` |
| 5 | `POST /v1/auth/token` | 401 | 17 | `qa-277f81c9-3b1b-4aba-8e82-7fb75e6a5242` |

## 1. POST /v1/accounts

```text
#1 POST http://localhost:7070/v1/accounts
correlation: qa-4b481a46-42c0-4955-ac08-5d96630ae470

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-4b481a46-42c0-4955-ac08-5d96630ae470
Content-Type: application/json

--- request body ---
{"handle":"qa-e31abe825ddd","displayName":"QA e31abe825ddd","password":"****","region":"in"}

--- response: 201 in 33 ms ---
Date: Thu, 22 Oct 2026 04:29:12 GMT
Content-Type: application/json
X-Correlation-Id: qa-4b481a46-42c0-4955-ac08-5d96630ae470
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 579
RateLimit-Reset: 9
Location: /v1/accounts/qa-e31abe825ddd
X-Served-Region: in
Content-Length: 178

{"id":"acc_a905c39a-600b-4f34-85d1-eda0786f9cda","handle":"qa-e31abe825ddd","displayName":"QA e31abe825ddd","region":"in","role":"user","createdAt":"2026-10-22T04:29:12.123593Z"}
```

## 2. POST /v1/auth/token

```text
#2 POST http://localhost:7070/v1/auth/token
correlation: qa-54151571-7590-4b87-9336-709bb30b1ddc

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-54151571-7590-4b87-9336-709bb30b1ddc
Content-Type: application/json

--- request body ---
{"handle":"qa-e31abe825ddd","password":"****"}

--- response: 200 in 242 ms ---
Date: Thu, 22 Oct 2026 04:29:12 GMT
Content-Type: application/json
X-Correlation-Id: qa-54151571-7590-4b87-9336-709bb30b1ddc
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 567
RateLimit-Reset: 9
Content-Length: 153

{"accessToken":"****","tokenType":"Bearer","expiresIn":900,"accountId":"acc_a905c39a-600b-4f34-85d1-eda0786f9cda"}
```

## 3. GET /v1/credits/balance

```text
#3 GET http://localhost:7070/v1/credits/balance
correlation: qa-831fd29f-2fbc-4bff-ad38-5b0c2854de35

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-831fd29f-2fbc-4bff-ad38-5b0c2854de35
Content-Type: application/json

--- response: 200 in 63 ms ---
Date: Thu, 22 Oct 2026 04:29:12 GMT
Content-Type: application/json
X-Correlation-Id: qa-831fd29f-2fbc-4bff-ad38-5b0c2854de35
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 60
RateLimit-Remaining: 59
RateLimit-Reset: 10
X-Served-Region: in
Content-Length: 98

{"availableBalance":5,"currency":"credits","accountId":"acc_a905c39a-600b-4f34-85d1-eda0786f9cda"}
```

## 4. DELETE /v1/accounts/me

```text
#4 DELETE http://localhost:7070/v1/accounts/me
correlation: qa-6ebeef94-0652-4a28-b6ae-befc48d310d3

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-6ebeef94-0652-4a28-b6ae-befc48d310d3
Content-Type: application/json

--- response: 204 in 86 ms ---
Date: Thu, 22 Oct 2026 04:29:12 GMT
Content-Type: text/plain
X-Correlation-Id: qa-6ebeef94-0652-4a28-b6ae-befc48d310d3
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 60
RateLimit-Remaining: 58
RateLimit-Reset: 10
X-Served-Region: in
```

## 5. POST /v1/auth/token

```text
#5 POST http://localhost:7070/v1/auth/token
correlation: qa-277f81c9-3b1b-4aba-8e82-7fb75e6a5242

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-277f81c9-3b1b-4aba-8e82-7fb75e6a5242
Content-Type: application/json

--- request body ---
{"handle":"qa-e31abe825ddd","password":"****"}

--- response: 401 in 17 ms ---
Date: Thu, 22 Oct 2026 04:29:12 GMT
Content-Type: application/problem+json
X-Correlation-Id: qa-277f81c9-3b1b-4aba-8e82-7fb75e6a5242
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 561
RateLimit-Reset: 8
Content-Length: 242

{"type":"https://reference-service.example/problems/invalid-credentials","title":"Invalid credentials","status":401,"detail":"Handle or password is wrong.","instance":"/v1/auth/token","correlationId":"qa-277f81c9-3b1b-4aba-8e82-7fb75e6a5242"}
```
