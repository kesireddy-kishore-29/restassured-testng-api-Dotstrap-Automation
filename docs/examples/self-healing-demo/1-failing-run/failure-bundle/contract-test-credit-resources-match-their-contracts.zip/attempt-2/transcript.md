# Transcript: Balance, ledger and purchase match their schemas

| | |
|---|---|
| Test | `com.qaautomation.tests.contract.ContractTest#creditResourcesMatchTheirContracts` |
| Features | FEAT-CONTRACT-01 |
| Attempt | 2 |
| Status | retried |
| Calls | 5 |

Secrets (tokens, passwords, credential headers) are masked as `****`.

| # | Call | Status | ms | Correlation ID |
|---|---|---|---|---|
| 1 | `POST /v1/accounts` | 201 | 25 | `qa-a50e7fc6-e8cf-4480-94d0-8ee7f2c2c554` |
| 2 | `POST /v1/auth/token` | 200 | 16 | `qa-83b97c9f-50aa-4b56-be45-280bcb2b24d4` |
| 3 | `GET /v1/credits/balance` | 200 | 10 | `qa-243b7530-a49e-4248-a239-f2ba8358a618` |
| 4 | `DELETE /v1/accounts/me` | 204 | 11 | `qa-f8595c2c-992f-4c98-a963-e94ddafcdcc6` |
| 5 | `POST /v1/auth/token` | 401 | 11 | `qa-b76024ac-7d6a-4cea-b4ff-18c9c95ec36c` |

## 1. POST /v1/accounts

```text
#1 POST http://localhost:7070/v1/accounts
correlation: qa-a50e7fc6-e8cf-4480-94d0-8ee7f2c2c554

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-a50e7fc6-e8cf-4480-94d0-8ee7f2c2c554
Content-Type: application/json

--- request body ---
{"handle":"qa-c0164b495132","displayName":"QA c0164b495132","password":"****","region":"in"}

--- response: 201 in 25 ms ---
Date: Wed, 21 Oct 2026 16:07:30 GMT
Content-Type: application/json
X-Correlation-Id: qa-a50e7fc6-e8cf-4480-94d0-8ee7f2c2c554
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 577
RateLimit-Reset: 9
Location: /v1/accounts/qa-c0164b495132
X-Served-Region: in
Content-Length: 181

{"id":"acc_d2d0b6fe-8603-4fb0-b5a8-d845ca272203","handle":"qa-c0164b495132","displayName":"QA c0164b495132","region":"in","role":"user","createdAt":"2026-10-21T16:07:30.846756900Z"}
```

## 2. POST /v1/auth/token

```text
#2 POST http://localhost:7070/v1/auth/token
correlation: qa-83b97c9f-50aa-4b56-be45-280bcb2b24d4

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-83b97c9f-50aa-4b56-be45-280bcb2b24d4
Content-Type: application/json

--- request body ---
{"handle":"qa-c0164b495132","password":"****"}

--- response: 200 in 16 ms ---
Date: Wed, 21 Oct 2026 16:07:30 GMT
Content-Type: application/json
X-Correlation-Id: qa-83b97c9f-50aa-4b56-be45-280bcb2b24d4
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 574
RateLimit-Reset: 9
Content-Length: 153

{"accessToken":"****","tokenType":"Bearer","expiresIn":900,"accountId":"acc_d2d0b6fe-8603-4fb0-b5a8-d845ca272203"}
```

## 3. GET /v1/credits/balance

```text
#3 GET http://localhost:7070/v1/credits/balance
correlation: qa-243b7530-a49e-4248-a239-f2ba8358a618

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-243b7530-a49e-4248-a239-f2ba8358a618
Content-Type: application/json

--- response: 200 in 10 ms ---
Date: Wed, 21 Oct 2026 16:07:30 GMT
Content-Type: application/json
X-Correlation-Id: qa-243b7530-a49e-4248-a239-f2ba8358a618
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 60
RateLimit-Remaining: 59
RateLimit-Reset: 10
X-Served-Region: in
Content-Length: 98

{"availableBalance":5,"currency":"credits","accountId":"acc_d2d0b6fe-8603-4fb0-b5a8-d845ca272203"}
```

## 4. DELETE /v1/accounts/me

```text
#4 DELETE http://localhost:7070/v1/accounts/me
correlation: qa-f8595c2c-992f-4c98-a963-e94ddafcdcc6

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-f8595c2c-992f-4c98-a963-e94ddafcdcc6
Content-Type: application/json

--- response: 204 in 11 ms ---
Date: Wed, 21 Oct 2026 16:07:30 GMT
Content-Type: text/plain
X-Correlation-Id: qa-f8595c2c-992f-4c98-a963-e94ddafcdcc6
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 60
RateLimit-Remaining: 58
RateLimit-Reset: 10
X-Served-Region: in
```

## 5. POST /v1/auth/token

```text
#5 POST http://localhost:7070/v1/auth/token
correlation: qa-b76024ac-7d6a-4cea-b4ff-18c9c95ec36c

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-b76024ac-7d6a-4cea-b4ff-18c9c95ec36c
Content-Type: application/json

--- request body ---
{"handle":"qa-c0164b495132","password":"****"}

--- response: 401 in 11 ms ---
Date: Wed, 21 Oct 2026 16:07:30 GMT
Content-Type: application/problem+json
X-Correlation-Id: qa-b76024ac-7d6a-4cea-b4ff-18c9c95ec36c
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 571
RateLimit-Reset: 9
Content-Length: 242

{"type":"https://reference-service.example/problems/invalid-credentials","title":"Invalid credentials","status":401,"detail":"Handle or password is wrong.","instance":"/v1/auth/token","correlationId":"qa-b76024ac-7d6a-4cea-b4ff-18c9c95ec36c"}
```
