# Transcript: Balance, ledger and purchase match their schemas

| | |
|---|---|
| Test | `com.kishore.qa.tests.contract.ContractTest#creditResourcesMatchTheirContracts` |
| Features | FEAT-CONTRACT-01 |
| Attempt | 2 |
| Status | retried |
| Calls | 5 |

Secrets (tokens, passwords, credential headers) are masked as `****`.

| # | Call | Status | ms | Correlation ID |
|---|---|---|---|---|
| 1 | `POST /v1/accounts` | 201 | 40 | `qa-99154476-a5e3-419a-a2ae-b1936aa2e39e` |
| 2 | `POST /v1/auth/token` | 200 | 19 | `qa-e28387f6-b83a-43c3-9be8-9d9cc9797b15` |
| 3 | `GET /v1/credits/balance` | 200 | 9 | `qa-a750e7e5-7370-4583-b3e8-fff54d0111f5` |
| 4 | `DELETE /v1/accounts/me` | 204 | 9 | `qa-b7518aa2-0b67-4377-a8ce-b71991b8d1b2` |
| 5 | `POST /v1/auth/token` | 401 | 8 | `qa-a5776fc4-b45e-49b6-8133-fdb38dabaf8e` |

## 1. POST /v1/accounts

```text
#1 POST http://localhost:7070/v1/accounts
correlation: qa-99154476-a5e3-419a-a2ae-b1936aa2e39e

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-99154476-a5e3-419a-a2ae-b1936aa2e39e
Content-Type: application/json

--- request body ---
{"handle":"qa-fb35e6833a39","displayName":"QA fb35e6833a39","password":"****","region":"in"}

--- response: 201 in 40 ms ---
Date: Wed, 21 Oct 2026 06:08:01 GMT
Content-Type: application/json
X-Correlation-Id: qa-99154476-a5e3-419a-a2ae-b1936aa2e39e
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 576
RateLimit-Reset: 10
Location: /v1/accounts/qa-fb35e6833a39
X-Served-Region: in
Content-Length: 181

{"id":"acc_8b8d7fab-14a3-4b8e-9ed1-3cb20d67ad5c","handle":"qa-fb35e6833a39","displayName":"QA fb35e6833a39","region":"in","role":"user","createdAt":"2026-10-21T06:08:01.929833600Z"}
```

## 2. POST /v1/auth/token

```text
#2 POST http://localhost:7070/v1/auth/token
correlation: qa-e28387f6-b83a-43c3-9be8-9d9cc9797b15

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-e28387f6-b83a-43c3-9be8-9d9cc9797b15
Content-Type: application/json

--- request body ---
{"handle":"qa-fb35e6833a39","password":"****"}

--- response: 200 in 19 ms ---
Date: Wed, 21 Oct 2026 06:08:01 GMT
Content-Type: application/json
X-Correlation-Id: qa-e28387f6-b83a-43c3-9be8-9d9cc9797b15
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 573
RateLimit-Reset: 9
Content-Length: 153

{"accessToken":"****","tokenType":"Bearer","expiresIn":900,"accountId":"acc_8b8d7fab-14a3-4b8e-9ed1-3cb20d67ad5c"}
```

## 3. GET /v1/credits/balance

```text
#3 GET http://localhost:7070/v1/credits/balance
correlation: qa-a750e7e5-7370-4583-b3e8-fff54d0111f5

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-a750e7e5-7370-4583-b3e8-fff54d0111f5
Content-Type: application/json

--- response: 200 in 9 ms ---
Date: Wed, 21 Oct 2026 06:08:01 GMT
Content-Type: application/json
X-Correlation-Id: qa-a750e7e5-7370-4583-b3e8-fff54d0111f5
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 60
RateLimit-Remaining: 59
RateLimit-Reset: 10
X-Served-Region: in
Content-Length: 98

{"availableBalance":5,"currency":"credits","accountId":"acc_8b8d7fab-14a3-4b8e-9ed1-3cb20d67ad5c"}
```

## 4. DELETE /v1/accounts/me

```text
#4 DELETE http://localhost:7070/v1/accounts/me
correlation: qa-b7518aa2-0b67-4377-a8ce-b71991b8d1b2

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-b7518aa2-0b67-4377-a8ce-b71991b8d1b2
Content-Type: application/json

--- response: 204 in 9 ms ---
Date: Wed, 21 Oct 2026 06:08:02 GMT
Content-Type: text/plain
X-Correlation-Id: qa-b7518aa2-0b67-4377-a8ce-b71991b8d1b2
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 60
RateLimit-Remaining: 58
RateLimit-Reset: 10
X-Served-Region: in
```

## 5. POST /v1/auth/token

```text
#5 POST http://localhost:7070/v1/auth/token
correlation: qa-a5776fc4-b45e-49b6-8133-fdb38dabaf8e

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-a5776fc4-b45e-49b6-8133-fdb38dabaf8e
Content-Type: application/json

--- request body ---
{"handle":"qa-fb35e6833a39","password":"****"}

--- response: 401 in 8 ms ---
Date: Wed, 21 Oct 2026 06:08:02 GMT
Content-Type: application/problem+json
X-Correlation-Id: qa-a5776fc4-b45e-49b6-8133-fdb38dabaf8e
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 571
RateLimit-Reset: 9
Content-Length: 242

{"type":"https://reference-service.example/problems/invalid-credentials","title":"Invalid credentials","status":401,"detail":"Handle or password is wrong.","instance":"/v1/auth/token","correlationId":"qa-a5776fc4-b45e-49b6-8133-fdb38dabaf8e"}
```
