# Transcript: Balance, ledger and purchase match their schemas

| | |
|---|---|
| Test | `com.qaautomation.tests.contract.ContractTest#creditResourcesMatchTheirContracts` |
| Features | FEAT-CONTRACT-01 |
| Attempt | 2 |
| Status | retried |
| Calls | 5 |

Secrets (tokens, passwords, credential headers) are masked as `****`.

| # | Call | Status | ms | Correlation ID |
|---|---|---|---|---|
| 1 | `POST /v1/accounts` | 201 | 19 | `qa-076d1338-d9df-40dd-9676-1bdb6d706e13` |
| 2 | `POST /v1/auth/token` | 200 | 46 | `qa-ff92d023-788c-4658-9488-2c61e0d9556a` |
| 3 | `GET /v1/credits/balance` | 200 | 10 | `qa-896aff01-533d-48c4-b1dc-b4295dca4fae` |
| 4 | `DELETE /v1/accounts/me` | 204 | 10 | `qa-b05ac04b-91bc-42df-9316-29aa92d1d940` |
| 5 | `POST /v1/auth/token` | 401 | 9 | `qa-872ec68d-759d-495d-962d-24691ebf667e` |

## 1. POST /v1/accounts

```text
#1 POST http://localhost:7070/v1/accounts
correlation: qa-076d1338-d9df-40dd-9676-1bdb6d706e13

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-076d1338-d9df-40dd-9676-1bdb6d706e13
Content-Type: application/json

--- request body ---
{"handle":"qa-3e0de1539df8","displayName":"QA 3e0de1539df8","password":"****","region":"in"}

--- response: 201 in 19 ms ---
Date: Wed, 21 Oct 2026 14:51:09 GMT
Content-Type: application/json
X-Correlation-Id: qa-076d1338-d9df-40dd-9676-1bdb6d706e13
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 577
RateLimit-Reset: 9
Location: /v1/accounts/qa-3e0de1539df8
X-Served-Region: in
Content-Length: 181

{"id":"acc_7bd5a535-1d67-4fd9-9c39-0b3756b2dee7","handle":"qa-3e0de1539df8","displayName":"QA 3e0de1539df8","region":"in","role":"user","createdAt":"2026-10-21T14:51:09.526019700Z"}
```

## 2. POST /v1/auth/token

```text
#2 POST http://localhost:7070/v1/auth/token
correlation: qa-ff92d023-788c-4658-9488-2c61e0d9556a

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-ff92d023-788c-4658-9488-2c61e0d9556a
Content-Type: application/json

--- request body ---
{"handle":"qa-3e0de1539df8","password":"****"}

--- response: 200 in 46 ms ---
Date: Wed, 21 Oct 2026 14:51:09 GMT
Content-Type: application/json
X-Correlation-Id: qa-ff92d023-788c-4658-9488-2c61e0d9556a
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 575
RateLimit-Reset: 9
Content-Length: 153

{"accessToken":"****","tokenType":"Bearer","expiresIn":900,"accountId":"acc_7bd5a535-1d67-4fd9-9c39-0b3756b2dee7"}
```

## 3. GET /v1/credits/balance

```text
#3 GET http://localhost:7070/v1/credits/balance
correlation: qa-896aff01-533d-48c4-b1dc-b4295dca4fae

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-896aff01-533d-48c4-b1dc-b4295dca4fae
Content-Type: application/json

--- response: 200 in 10 ms ---
Date: Wed, 21 Oct 2026 14:51:09 GMT
Content-Type: application/json
X-Correlation-Id: qa-896aff01-533d-48c4-b1dc-b4295dca4fae
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 60
RateLimit-Remaining: 59
RateLimit-Reset: 10
X-Served-Region: in
Content-Length: 98

{"availableBalance":5,"currency":"credits","accountId":"acc_7bd5a535-1d67-4fd9-9c39-0b3756b2dee7"}
```

## 4. DELETE /v1/accounts/me

```text
#4 DELETE http://localhost:7070/v1/accounts/me
correlation: qa-b05ac04b-91bc-42df-9316-29aa92d1d940

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-b05ac04b-91bc-42df-9316-29aa92d1d940
Content-Type: application/json

--- response: 204 in 10 ms ---
Date: Wed, 21 Oct 2026 14:51:09 GMT
Content-Type: text/plain
X-Correlation-Id: qa-b05ac04b-91bc-42df-9316-29aa92d1d940
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 60
RateLimit-Remaining: 58
RateLimit-Reset: 10
X-Served-Region: in
```

## 5. POST /v1/auth/token

```text
#5 POST http://localhost:7070/v1/auth/token
correlation: qa-872ec68d-759d-495d-962d-24691ebf667e

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-872ec68d-759d-495d-962d-24691ebf667e
Content-Type: application/json

--- request body ---
{"handle":"qa-3e0de1539df8","password":"****"}

--- response: 401 in 9 ms ---
Date: Wed, 21 Oct 2026 14:51:09 GMT
Content-Type: application/problem+json
X-Correlation-Id: qa-872ec68d-759d-495d-962d-24691ebf667e
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 573
RateLimit-Reset: 9
Content-Length: 242

{"type":"https://reference-service.example/problems/invalid-credentials","title":"Invalid credentials","status":401,"detail":"Handle or password is wrong.","instance":"/v1/auth/token","correlationId":"qa-872ec68d-759d-495d-962d-24691ebf667e"}
```
