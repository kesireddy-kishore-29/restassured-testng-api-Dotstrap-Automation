# Transcript: Balance, ledger and purchase match their schemas

| | |
|---|---|
| Test | `com.qaautomation.tests.contract.ContractTest#creditResourcesMatchTheirContracts` |
| Features | FEAT-CONTRACT-01 |
| Attempt | 3 |
| Status | failed |
| Calls | 5 |

Secrets (tokens, passwords, credential headers) are masked as `****`.

| # | Call | Status | ms | Correlation ID |
|---|---|---|---|---|
| 1 | `POST /v1/accounts` | 201 | 54 | `qa-4de16278-d107-4a95-8b97-6dd1da400671` |
| 2 | `POST /v1/auth/token` | 200 | 34 | `qa-375171ea-af38-4fd4-83b6-93bde1b8f504` |
| 3 | `GET /v1/credits/balance` | 200 | 13 | `qa-9f5e5574-dbac-4074-9be3-f5795bdcd209` |
| 4 | `DELETE /v1/accounts/me` | 204 | 16 | `qa-25abec36-fef8-4bbf-aabc-e71d5cb4aee4` |
| 5 | `POST /v1/auth/token` | 401 | 15 | `qa-3433f3d3-05bc-4090-a937-eb970c44e5f1` |

## 1. POST /v1/accounts

```text
#1 POST http://localhost:7070/v1/accounts
correlation: qa-4de16278-d107-4a95-8b97-6dd1da400671

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-4de16278-d107-4a95-8b97-6dd1da400671
Content-Type: application/json

--- request body ---
{"handle":"qa-f50ac89b6c9d","displayName":"QA f50ac89b6c9d","password":"****","region":"in"}

--- response: 201 in 54 ms ---
Date: Thu, 22 Oct 2026 04:29:12 GMT
Content-Type: application/json
X-Correlation-Id: qa-4de16278-d107-4a95-8b97-6dd1da400671
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 560
RateLimit-Reset: 8
Location: /v1/accounts/qa-f50ac89b6c9d
X-Served-Region: in
Content-Length: 181

{"id":"acc_67b9ad3f-ac93-4b9b-8329-4d40051005cf","handle":"qa-f50ac89b6c9d","displayName":"QA f50ac89b6c9d","region":"in","role":"user","createdAt":"2026-10-22T04:29:12.751829600Z"}
```

## 2. POST /v1/auth/token

```text
#2 POST http://localhost:7070/v1/auth/token
correlation: qa-375171ea-af38-4fd4-83b6-93bde1b8f504

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-375171ea-af38-4fd4-83b6-93bde1b8f504
Content-Type: application/json

--- request body ---
{"handle":"qa-f50ac89b6c9d","password":"****"}

--- response: 200 in 34 ms ---
Date: Thu, 22 Oct 2026 04:29:12 GMT
Content-Type: application/json
X-Correlation-Id: qa-375171ea-af38-4fd4-83b6-93bde1b8f504
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 559
RateLimit-Reset: 8
Content-Length: 153

{"accessToken":"****","tokenType":"Bearer","expiresIn":900,"accountId":"acc_67b9ad3f-ac93-4b9b-8329-4d40051005cf"}
```

## 3. GET /v1/credits/balance

```text
#3 GET http://localhost:7070/v1/credits/balance
correlation: qa-9f5e5574-dbac-4074-9be3-f5795bdcd209

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-9f5e5574-dbac-4074-9be3-f5795bdcd209
Content-Type: application/json

--- response: 200 in 13 ms ---
Date: Thu, 22 Oct 2026 04:29:12 GMT
Content-Type: application/json
X-Correlation-Id: qa-9f5e5574-dbac-4074-9be3-f5795bdcd209
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 60
RateLimit-Remaining: 59
RateLimit-Reset: 10
X-Served-Region: in
Content-Length: 98

{"availableBalance":5,"currency":"credits","accountId":"acc_67b9ad3f-ac93-4b9b-8329-4d40051005cf"}
```

## 4. DELETE /v1/accounts/me

```text
#4 DELETE http://localhost:7070/v1/accounts/me
correlation: qa-25abec36-fef8-4bbf-aabc-e71d5cb4aee4

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-25abec36-fef8-4bbf-aabc-e71d5cb4aee4
Content-Type: application/json

--- response: 204 in 16 ms ---
Date: Thu, 22 Oct 2026 04:29:12 GMT
Content-Type: text/plain
X-Correlation-Id: qa-25abec36-fef8-4bbf-aabc-e71d5cb4aee4
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 60
RateLimit-Remaining: 58
RateLimit-Reset: 10
X-Served-Region: in
```

## 5. POST /v1/auth/token

```text
#5 POST http://localhost:7070/v1/auth/token
correlation: qa-3433f3d3-05bc-4090-a937-eb970c44e5f1

--- request headers ---
Accept: application/json
X-Correlation-Id: qa-3433f3d3-05bc-4090-a937-eb970c44e5f1
Content-Type: application/json

--- request body ---
{"handle":"qa-f50ac89b6c9d","password":"****"}

--- response: 401 in 15 ms ---
Date: Thu, 22 Oct 2026 04:29:12 GMT
Content-Type: application/problem+json
X-Correlation-Id: qa-3433f3d3-05bc-4090-a937-eb970c44e5f1
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
Referrer-Policy: no-referrer
Strict-Transport-Security: max-age=31536000; includeSubDomains
Cache-Control: no-store
Vary: Origin
RateLimit-Limit: 600
RateLimit-Remaining: 556
RateLimit-Reset: 8
Content-Length: 242

{"type":"https://reference-service.example/problems/invalid-credentials","title":"Invalid credentials","status":401,"detail":"Handle or password is wrong.","instance":"/v1/auth/token","correlationId":"qa-3433f3d3-05bc-4090-a937-eb970c44e5f1"}
```
